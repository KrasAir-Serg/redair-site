<?php
// Copy to config.php here, outside public_html. Never publish the bot token.
return [
    'telegram_bot_token' => '',
    'telegram_chat_id' => '',
];
