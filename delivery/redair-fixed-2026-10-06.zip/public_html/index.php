<?php
// PHP 8+. Keep redair-private next to public_html, outside the public web directory.
ini_set('session.use_strict_mode', '1');
session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off','samesite'=>'Lax']);
session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
$template = dirname(__DIR__) . '/redair-private/storefront.html';
if (!is_readable($template)) {
    http_response_code(503);
    echo '<!doctype html><html lang="ru"><meta charset="utf-8"><title>RedAir</title><p>Сайт временно недоступен. Попробуйте позже.</p></html>';
    exit;
}
$html = file_get_contents($template);
if ($html === false) {
    http_response_code(503);
    exit('Сайт временно недоступен. Попробуйте позже.');
}
echo str_replace('</head>', '<meta name="csrf-token" content="'.htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8').'"></head>', $html);
