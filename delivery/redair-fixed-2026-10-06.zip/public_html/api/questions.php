<?php
// PHP 8+. Credentials stay in redair-private/config.php, outside public_html.
ini_set('session.use_strict_mode', '1');
session_set_cookie_params([
    'httponly' => true,
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Lax',
]);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function reply(string $message, int $status = 200): void {
    http_response_code($status);
    echo json_encode(['message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    reply('Метод не поддерживается.', 405);
}
if (!isset($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) {
    reply('Обновите страницу и попробуйте снова.', 403);
}
$contentType = strtolower(trim(explode(';', $_SERVER['CONTENT_TYPE'] ?? '')[0]));
if ($contentType !== 'application/json') reply('Неверный формат запроса.', 415);

// Includes room for all 20 items and JSON-escaped Unicode without truncating them.
$raw = file_get_contents('php://input', false, null, 0, 96001);
if ($raw === false) reply('Не удалось прочитать запрос.', 400);
if (strlen($raw) > 96000) reply('Слишком длинный запрос.', 413);
try {
    $payload = json_decode($raw, false, 32, JSON_THROW_ON_ERROR);
} catch (JsonException $error) {
    reply('Неверный формат запроса.', 400);
}
if (!$payload instanceof stdClass) reply('Неверный формат запроса.', 400);
$data = (array) $payload;
if (!empty($data['website'])) reply('Неверный формат запроса.', 400);

function field(array $data, string $key, int $max): string {
    if (!isset($data[$key])) return '';
    if (!is_string($data[$key])) reply('Неверный формат поля: ' . $key . '.', 400);
    $value = trim($data[$key]);
    if (!preg_match('/\A.{0,' . $max . '}\z/us', $value)) {
        reply('Слишком длинное или некорректное поле: ' . $key . '.', 400);
    }
    return $value;
}

$question = field($data, 'question', 2000);
$name = field($data, 'name', 80);
$product = field($data, 'product', 300);
$labels = ['phone' => 'Телефон', 'telegram' => 'Telegram', 'max' => 'MAX', 'whatsapp' => 'WhatsApp'];
$contacts = [];
foreach ($labels as $key => $label) {
    $value = field($data, $key, in_array($key, ['phone', 'whatsapp'], true) ? 40 : 100);
    if ($value !== '') $contacts[] = $label . ': ' . $value;
}
if (!preg_match('/\A.{5,}\z/us', $question) || !$contacts || ($data['consent'] ?? '') !== 'on') {
    reply('Введите вопрос, контакт и подтвердите согласие.', 400);
}
$selection = [];
if (isset($data['selection'])) {
    if (!is_array($data['selection']) || count($data['selection']) > 20) {
        reply('В запросе можно выбрать до 20 товаров.', 400);
    }
    foreach ($data['selection'] as $item) {
        $value = field(['item' => $item], 'item', 160);
        if ($value === '') reply('Пустой товар в списке выбора.', 400);
        if (!in_array($value, $selection, true)) $selection[] = $value;
    }
}
if (time() - ($_SESSION['last_question'] ?? 0) < 30) {
    header('Retry-After: ' . max(1, 30 - (time() - $_SESSION['last_question'])));
    reply('Подождите 30 секунд перед повторной отправкой.', 429);
}

$configFile = dirname(__DIR__, 2) . '/redair-private/config.php';
try {
    $config = is_file($configFile) ? require $configFile : [];
} catch (Throwable $error) {
    reply('Отправка вопросов пока не подключена. Напишите через объявления Avito.', 503);
}
if (!is_array($config) || empty($config['telegram_bot_token']) || empty($config['telegram_chat_id'])) {
    reply('Отправка вопросов пока не подключена. Попробуйте позже или напишите через объявления Avito.', 503);
}
if (!is_string($config['telegram_bot_token'])
    || (!is_string($config['telegram_chat_id']) && !is_int($config['telegram_chat_id']))
    || !function_exists('curl_init')) {
    reply('Отправка временно недоступна.', 503);
}

$lines = ['Новый вопрос — RedAir'];
if ($name !== '') $lines[] = 'Имя: ' . $name;
if ($product !== '') $lines[] = 'Товар или модель: ' . $product;
if ($selection) $lines[] = "Выбранные товары:\n• " . implode("\n• ", $selection);
$lines[] = 'Вопрос: ' . $question;
$text = implode("\n\n", array_merge($lines, $contacts));

// Telegram limits text length. Count astral characters as two UTF-16 units;
// leave space for part labels and preserve the complete question and selection.
$chunks = [];
$chunk = '';
$units = 0;
foreach (preg_split('//u', $text, -1, PREG_SPLIT_NO_EMPTY) as $character) {
    $size = strlen($character) === 4 ? 2 : 1;
    if ($units + $size > 3800) {
        $chunks[] = $chunk;
        $chunk = '';
        $units = 0;
    }
    $chunk .= $character;
    $units += $size;
}
if ($chunk !== '') $chunks[] = $chunk;

// Reserve the session before releasing its lock to avoid duplicate concurrent sends.
$_SESSION['last_question'] = time();
session_write_close();
$sent = 0;
foreach ($chunks as $index => $message) {
    if (count($chunks) > 1) {
        $message = 'Запрос RedAir — часть ' . ($index + 1) . '/' . count($chunks) . "\n\n" . $message;
    }
    $ch = curl_init('https://api.telegram.org/bot' . trim($config['telegram_bot_token']) . '/sendMessage');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode([
            'chat_id' => $config['telegram_chat_id'],
            'text' => $message,
            'link_preview_options' => ['is_disabled' => true],
        ], JSON_UNESCAPED_UNICODE),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $response = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $result = is_string($response) ? json_decode($response, true) : null;
    if ($code !== 200 || !is_array($result) || ($result['ok'] ?? false) !== true) {
        reply($sent > 0
            ? 'Вопрос передан частично. Полный запрос можно скопировать и отправить продавцу через Avito.'
            : 'Не удалось передать вопрос продавцу. Попробуйте позже или напишите через Avito.', 502);
    }
    $sent++;
}
reply('Вопрос отправлен.');
