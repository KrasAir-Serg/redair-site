'use strict';

const $ = id => document.getElementById(id);
const maxSelection = 20;
const storageKey = 'voltSelection'; // Preserve lists saved by the existing site.
const categories = [
  { name: 'Аккумуляторы', symbol: '▤' },
  { name: 'Зарядные устройства', symbol: 'ϟ' },
  { name: 'Шины и камеры', symbol: '◎' },
  { name: 'Тормозные компоненты', symbol: '◉' },
  { name: 'Электроника и проводка', symbol: '⌁' },
  { name: 'Элементы корпуса', symbol: '◇' },
];
const productCards = [...document.querySelectorAll('#parts article[data-models]')];
const normalize = value => value.toLowerCase().replaceAll('ё', 'е')
  .replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
let filter = 'Все модели';
let selected = [];
try {
  const stored = JSON.parse(localStorage.getItem(storageKey) || '[]');
  if (Array.isArray(stored)) {
    selected = [...new Set(stored.filter(item => typeof item === 'string'
      && item.trim() && [...item].length <= 160))].slice(0, maxSelection);
  }
} catch { /* Storage may be unavailable or contain invalid old data. */ }

function save() {
  try { localStorage.setItem(storageKey, JSON.stringify(selected)); } catch { }
  $('count').textContent = selected.length;
}

function add(name) {
  if (!selected.includes(name)) {
    if (selected.length >= maxSelection) {
      openDialog();
      $('status').textContent = 'В запросе можно выбрать до 20 товаров. Удалите лишние позиции.';
      return;
    }
    selected.push(name);
  }
  save();
  openDialog();
}

function render() {
  const terms = normalize($('search').value).split(' ').filter(Boolean);
  const matchesSearch = text => terms.every(term => normalize(text).includes(term));
  let visibleProducts = 0;
  for (const card of productCards) {
    const models = card.dataset.models.split('|');
    const matchesModel = filter === 'Все модели' || models.includes(filter)
      || (filter === 'Другие HIPER Slim'
        && models.some(model => model.startsWith('HIPER') && model !== 'HIPER Slim VX662'));
    const searchable = [card.querySelector('h3').textContent, card.dataset.models,
      card.dataset.keywords, card.querySelector('[data-add]').dataset.add].join(' ');
    card.hidden = !matchesModel || !matchesSearch(searchable);
    if (!card.hidden) visibleProducts++;
  }
  $('grid').replaceChildren();
  for (const { name, symbol } of categories.filter(category => matchesSearch(category.name))) {
    const card = document.createElement('article');
    card.className = 'part';
    const icon = document.createElement('div');
    icon.className = 'symbol';
    icon.textContent = symbol;
    icon.setAttribute('aria-hidden', 'true');
    const title = document.createElement('h3');
    title.textContent = name;
    const info = document.createElement('div');
    info.className = 'small';
    info.textContent = filter === 'Все модели' ? 'Подбор по модели и маркировке' : filter;
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = 'Добавить в запрос ↗';
    button.onclick = () => add(`${name} — ${filter === 'Все модели' ? 'модель уточнить' : filter}`);
    card.append(icon, title, info, button);
    $('grid').append(card);
  }
  const categoryCount = $('grid').children.length;
  $('catalogStatus').textContent = `Товары: ${visibleProducts} · Категории для подбора: ${categoryCount}`;
  $('catalogEmpty').hidden = visibleProducts > 0 || categoryCount > 0;
  document.querySelector('.category-heading').hidden = categoryCount === 0;
}

function updateMessage() {
  $('message').value = [
    'Здравствуйте! Интересуют:',
    selected.length ? selected.map(item => `• ${item}`).join('\n') : 'Самокаты или запчасти из каталога.',
    `Модель для подбора: ${$('modelSelect').value}.`,
    'Подскажите цену, наличие, состояние, совместимость и условия получения.',
  ].join('\n');
}

function openDialog() {
  $('selected').replaceChildren();
  if (!selected.length) $('selected').textContent = 'Список пока пуст. Добавьте самокат или запчасть из каталога.';
  for (const item of selected) {
    const row = document.createElement('div');
    row.className = 'selection-row';
    const label = document.createElement('span');
    label.textContent = item;
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'selection-remove';
    remove.textContent = 'Удалить';
    remove.setAttribute('aria-label', `Удалить: ${item}`);
    remove.onclick = () => {
      selected = selected.filter(value => value !== item);
      save();
      openDialog();
    };
    row.append(label, remove);
    $('selected').append(row);
  }
  updateMessage();
  $('status').textContent = '';
  if (!$('dialog').open) $('dialog').showModal();
}

document.querySelectorAll('[data-add]').forEach(button => {
  button.onclick = () => add(button.dataset.add);
});
document.querySelectorAll('[data-filter]').forEach(button => {
  button.onclick = () => {
    filter = button.dataset.filter;
    document.querySelectorAll('[data-filter]').forEach(other => {
      other.classList.toggle('active', other === button);
      other.setAttribute('aria-pressed', String(other === button));
    });
    if ([...$('modelSelect').options].some(option => option.value === filter)) {
      $('modelSelect').value = filter;
    } else {
      $('modelSelect').value = 'Уточнить модель';
    }
    render();
  };
});
document.querySelectorAll('[data-model]').forEach(button => {
  button.onclick = () => {
    $('search').value = '';
    [...document.querySelectorAll('[data-filter]')]
      .find(other => other.dataset.filter === button.dataset.model)?.click();
    $('parts').scrollIntoView({ behavior: 'smooth' });
  };
});
$('search').oninput = render;
$('basket').onclick = openDialog;
$('request').onclick = openDialog;
document.querySelector('.close').onclick = () => $('dialog').close();
$('modelSelect').onchange = updateMessage;
$('clear').onclick = () => { selected = []; save(); openDialog(); };
$('copy').onclick = async () => {
  try {
    await navigator.clipboard.writeText($('message').value);
    $('status').textContent = 'Запрос скопирован.';
  } catch {
    $('message').select();
    $('status').textContent = 'Выделен текст запроса. Скопируйте его вручную.';
  }
};
$('askSelected').onclick = () => {
  $('dialog').close();
  // The full list is sent separately; this field holds the selected model.
  $('questionProduct').value = $('modelSelect').value === 'Уточнить модель'
    ? '' : $('modelSelect').value;
  $('question').scrollIntoView({ behavior: 'smooth' });
  $('questionForm').elements.question.focus({ preventScroll: true });
};

$('questionForm').onsubmit = async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const status = $('questionStatus');
  const data = Object.fromEntries(new FormData(form));
  const contacts = ['phone', 'telegram', 'max', 'whatsapp'];
  if (!String(data.question || '').trim() || [...data.question.trim()].length < 5) {
    status.textContent = 'Введите вопрос длиной не менее пяти символов.';
    form.elements.question.focus();
    return;
  }
  if (!contacts.some(key => String(data[key] || '').trim())) {
    status.textContent = 'Укажите хотя бы один контакт: телефон, Telegram, MAX или WhatsApp.';
    form.elements.phone.setAttribute('aria-invalid', 'true');
    form.elements.phone.focus();
    return;
  }
  form.elements.phone.removeAttribute('aria-invalid');
  const token = document.querySelector('meta[name="csrf-token"]')?.content;
  if (!token) {
    status.textContent = 'Обновите страницу перед отправкой вопроса.';
    return;
  }
  data.selection = [...selected];
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  status.textContent = 'Отправляем вопрос…';
  try {
    const response = await fetch('/api/questions.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token },
      body: JSON.stringify(data),
    });
    const result = await response.json().catch(() => null);
    if (!response.ok || !result || typeof result.message !== 'string') {
      throw new Error(result?.message || 'Не удалось отправить вопрос. Попробуйте позже или напишите через Avito.');
    }
    status.textContent = 'Вопрос отправлен. Продавец ответит по указанным контактам.';
    form.reset();
  } catch (error) {
    status.textContent = error.message === 'Failed to fetch'
      ? 'Не удалось отправить вопрос. Проверьте соединение и попробуйте позже.'
      : error.message || 'Не удалось отправить вопрос. Попробуйте позже.';
  } finally {
    button.disabled = false;
  }
};

save();
render();
